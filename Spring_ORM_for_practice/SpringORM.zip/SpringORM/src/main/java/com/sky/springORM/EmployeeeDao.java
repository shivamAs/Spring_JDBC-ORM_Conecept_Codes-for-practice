package com.sky.springORM;

import javax.transaction.Transactional;

import org.springframework.orm.hibernate5.HibernateTemplate;

public class EmployeeeDao {
	
	
	private HibernateTemplate hibernateTemplate;
	@Transactional
	public int insert(Employeee employeee)
	{
		Integer i = (Integer) this.hibernateTemplate.save(employeee);
		return i;
	}

	public HibernateTemplate getHibernateTemplate() {
		return hibernateTemplate;
	}

	public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
		this.hibernateTemplate = hibernateTemplate;
	}
	
	

}
