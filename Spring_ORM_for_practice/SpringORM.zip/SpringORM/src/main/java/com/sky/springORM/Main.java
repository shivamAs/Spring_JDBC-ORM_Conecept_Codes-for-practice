package com.sky.springORM;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main 
{
    public static void main( String[] args )
    {
    	
    ApplicationContext context =new ClassPathXmlApplicationContext("com/sky/springORM/Config.xml");
    
    EmployeeeDao employeeeDao= (EmployeeeDao) context.getBean("EmployeeeDao");
    Employeee employeee=new Employeee(100,"Elvish Yadav", 19);
    int r = employeeeDao.insert(employeee);
    System.out.println("Done....... " + r);
    }
}
