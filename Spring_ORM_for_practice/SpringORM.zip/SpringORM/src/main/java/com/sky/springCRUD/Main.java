package com.sky.springCRUD;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/springCRUD/Config.xml");
		StudentDao studentDao = context.getBean("studentDao" , StudentDao.class);
//		
//		Student student = new Student(100,"Elvish","lucknow");
//		int r = studentDao.insert(student);
//		
//		System.out.println("Done............ " +r);
//		
//	
		
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		
		boolean go = true;
		while(go) {
		
		System.out.println("********   ❤     Welcome to the Console Based Application    ❤   ****");
		System.out.println();
		System.out.println("Press 1 for add new Student");
		System.out.println("Press 2 for display all Student");
		System.out.println("Press 3 for get details of single Student");
		System.out.println("Press 4 for delete Students");
		System.out.println("Press 5 for update Student");
		System.out.println("Press 6 for exit");
		
		
		try {
			int input = Integer.parseInt(br.readLine());
			
			switch (input) {
			case 1:
				// add a new student
				//taking inputs from user
				System.out.println("Enter user id : ");
				int uId = Integer.parseInt(br.readLine());
				
				System.out.println("Enter user Name : ");
				String uName = br.readLine();
				
				System.out.println("Enter user City : ");
				String uCity = br.readLine();
				
				//creating students objects and setting values
				Student s= new Student(uId, uName, uName);
				s.setStudentId(uId);
				s.setStudentName(uName);
				s.setStudentCity(uCity);
				
				//saving student objects to databse by insertion of DAO
				int r = studentDao.insert(s);
				System.out.println(r + " Student added ");
				System.out.println("************************ 😍    *********************************");
				System.out.println();
				break;

			case 2:
				// display all student
				System.out.println("*********************************************");
			List<Student> allStudents = studentDao.getAllStudent();
			for(Student st:allStudents)
			{
				System.out.println("Id : " +st.getStudentId());
				System.out.println("Name : "+st.getStudentName());
				System.out.println("City : "+st.getStudentCity());
				System.out.println("*******************************************");
			}
				break;
				
			case 3:
				//get single student
				
				System.out.println("Enter User id : ");
				int userId = Integer.parseInt(br.readLine());
				Student student = studentDao.getStudent(userId);
				System.out.println("Id : " +student.getStudentId());
				System.out.println("Name : "+student.getStudentName());
				System.out.println("City : "+student.getStudentCity());
				System.out.println("*******************************************");
				break;
				
			case 4:
				//delete student
				System.out.println("Enter user Id : ");
				int id = Integer.parseInt(br.readLine());
				studentDao.deleteStudet(id);
				System.out.println("Student Deleated .....  🙄😢");
				break;
			case 5:
				//updating data
			
				
				break;
			case 6:
				//exit 
				go=false;
				break;
			}
			
		}
		catch (Exception e ) {
			System.out.println("Invalid Input Try other one");
		}
		
	}
System.out.println("Thank for using application");
System.out.println("See you next time !  😍❤❤❤✔   ");
	}
}
