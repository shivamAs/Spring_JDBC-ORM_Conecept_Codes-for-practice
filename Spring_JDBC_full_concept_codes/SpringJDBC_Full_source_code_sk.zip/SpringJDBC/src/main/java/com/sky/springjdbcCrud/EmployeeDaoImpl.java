package com.sky.springjdbcCrud;

import org.springframework.jdbc.core.JdbcTemplate;

public class EmployeeDaoImpl implements EmployeeDao {
	private JdbcTemplate jdbcTemplate;
	final String INSERT_QUERY = "insert into employee (empId, empName,empAge) values (?, ?, ?)";
	final String UPDATE_QUERY = "update employee set age = ? where id = ?";
	final String DELETE_QUERY = "delete from employee where id = ?";

	public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public int save(Employee2 employee) {
		return jdbcTemplate.update(INSERT_QUERY, employee.getempId(), employee.getempName(), employee.getAge());
	}

	public void update(Employee2 employee) {
		int status = jdbcTemplate.update(UPDATE_QUERY, employee.getempId(), employee.getAge(), employee.getempName());
		if (status != 0) {
			System.out.println("Employee data updated for ID " + employee.getempId());
		} else {
			System.out.println("No Employee found with ID " + employee.getempId());
		}
	}

	public void deleteEmpById(int empId) {
		int status = jdbcTemplate.update(DELETE_QUERY, empId);
		if (status != 0) {
			System.out.println("Employee data deleted for ID " + empId);
		} else {
			System.out.println("No Employee found with ID " + empId);
		}
	}

	public void deleteempById(int empId) {
		// TODO Auto-generated method stub
		
	}
}