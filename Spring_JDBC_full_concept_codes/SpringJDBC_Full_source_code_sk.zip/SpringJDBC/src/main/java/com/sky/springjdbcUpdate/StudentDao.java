package com.sky.springjdbcUpdate;


public interface StudentDao {

	int insert(Student student);


}
