package com.sky.springjdbcRowmapper;

import java.util.List;

public interface StudentDao {
	   
	    public List<Student> getAllStudentDetails();
	  
	}


