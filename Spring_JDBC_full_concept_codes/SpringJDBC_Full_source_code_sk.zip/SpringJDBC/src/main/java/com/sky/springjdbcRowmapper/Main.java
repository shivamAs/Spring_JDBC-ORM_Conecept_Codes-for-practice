package com.sky.springjdbcRowmapper;

import java.util.List;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext(
				"com/sky/springjdbcRowmapper/Config.xml");

		StudentDaoImpl studentDaoImpl = (StudentDaoImpl) context.getBean("studentDao");

		List<Student> studentDetailList = studentDaoImpl.getAllStudentDetails();

		for (Student index : studentDetailList) {
			System.out.println(index);
		}

	}
}
