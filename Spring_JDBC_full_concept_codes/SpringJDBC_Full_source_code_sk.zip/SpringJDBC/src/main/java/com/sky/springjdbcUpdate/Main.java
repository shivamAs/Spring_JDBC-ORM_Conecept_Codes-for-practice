package com.sky.springjdbcUpdate;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext context=new ClassPathXmlApplicationContext("com/sky/springjdbcUpdate/Config.xml");

		StudentDao studentDao = context.getBean("studentDao", StudentDao.class);
		
		Student student = new Student();
		student.setId(92);
		student.setName("Elvish Yadav");
		student.setCity("Lucknow");
		
		int result = studentDao.insert(student);
		
		System.out.println("Records inserted --------> " +result);
		
	}

}
