package com.sky.springjdbc;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;

public class Main {
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("com/sky/springjdbc/Config.xml");

		JdbcTemplate template = context.getBean("jdbcTemplate", JdbcTemplate.class);

	
		String query = "insert into student(id,name,city) values (?,?,?)";

		
		int result = template.update(query, 95, "Suryansh ", "Mumbai");
		System.out.println("Number of record inserted -----> " + result);

	}
}
