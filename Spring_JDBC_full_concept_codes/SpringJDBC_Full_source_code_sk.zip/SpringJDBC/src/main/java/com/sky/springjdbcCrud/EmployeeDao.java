package com.sky.springjdbcCrud;


public interface EmployeeDao {
 public int save(Employee2 employee);
 
 public void update(Employee2 employee);
 
 public void deleteempById(int empId);
}
