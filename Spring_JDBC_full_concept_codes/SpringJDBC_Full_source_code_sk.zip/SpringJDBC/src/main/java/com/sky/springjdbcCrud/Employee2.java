package com.sky.springjdbcCrud;

public class Employee2 {
	 private int empId;
	 private String empName;
	 private int Age;
	 
	 public int getempId() {
	  return empId;
	 }
	 public void setempId(int empId) {
	  this.empId = empId;
	 }
	 public String getempName() {
	  return empName;
	 }
	 public void setempName(String empName) {
	  this.empName = empName;
	 }
	 public int getAge() {
	  return Age;
	 }
	 public void setAge(int age) {
	  this.Age = age;
	 }
	}