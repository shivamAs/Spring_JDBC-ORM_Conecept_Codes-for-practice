package com.sky.springjdbcCrud;

import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
		  public static void main(String[] args) {
		    ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext
		    ("com/sky/springjdbcCrud/Config.xml");

		    EmployeeDao dao=(EmployeeDao)context.getBean("employeeDao");  
		    Employee2 emp = new Employee2();
		    emp.setempId(10);
		    emp.setempName("Elvish Yadav");
		    emp.setAge(12);
		   
		    int status = dao.save(emp);  
		    System.out.println(status);  
		   
		  }
		}

